function setup() {
  createCanvas(800, 800);
}

function draw() {
  rect(0, 0, 850, 850);
  fill("tan");
  rect(0, 600, 850, 850)
  fill("gold");
  strokeWeight(6);
  triangle(550, 400, 680, 470, 680, 330);
  ellipse(500, 400, 200, 140);
  strokeWeight(1);
  fill("orange");
  triangle(430, 400, 510, 450, 490, 400);
  strokeWeight(6);
  fill("white")
  ellipse(460, 370, 30, 30);
  strokeWeight(0)
  fill("black")
  ellipse(460, 370, 10, 10);
  fill("blue");
}